/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fdsystem;
import java.sql.*;
/**
 *
 * @author HNDX
 */
public class DBC {
    static private Connection con;
     public static Connection getConnection() throws Exception{
         if(con==null){
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Restaurant","root","000618");
         }
         return con;
     }
}
